namespace YoukuSpeed
{
    using Fiddler;
    using Microsoft.Win32;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Drawing;
    using System.IO;
    using System.Management;
    using System.Runtime.InteropServices;
    using System.Security.Cryptography;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Threading;
    using System.Windows.Forms;
   
    public class FormMain : Form
    {
        private Button button1;
        private Button buttonAdd;
        private Button buttonDelete;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private IContainer components = null;
        private int intFlag = 0;
        private static int iSecureEndpointPort = 0x1e61;
        private Label label1;
        private Label label10;
        private Label label11;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label labelMachineID;
        private ListView listView1;
        private string machineID;
        private NumericUpDown numericUpDown1;
        private NumericUpDown numericUpDown2;
        private NumericUpDown numericUpDown3;
        private NumericUpDown numericUpDown4;
        private NumericUpDown numericUpDown5;
        private NumericUpDown numericUpDown6;
        private NumericUpDown numericUpDown7;
        private NumericUpDown numericUpDown8;
        private static Proxy oSecureEndpoint;
        private static string sSecureEndpointHostname = "localhost";
        private TextBox textBoxID;
        private TextBox textBoxMachineID;
        private TextBox textBoxTime;
        private TextBox textBoxlog;
        private TextBox txtKey;

        public FormMain()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string str = "";
            str = this.makeKey();
            MessageBox.Show(str);
            if (this.txtKey.Text.Trim() == this.makeKey())
            {
                MessageBox.Show("注册成功，欢迎使用哟!");
                this.intFlag = 1;
                this.txtKey.Enabled = false;
                this.button1.Enabled = false;
                File.WriteAllText(Thread.GetDomain().BaseDirectory + "key.txt", this.txtKey.Text.Trim());
            }
            else
            {
                this.intFlag = 0;
                MessageBox.Show("哦，注册码好像不对哟");
            }
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if ((this.textBoxID.Text != "") && (this.textBoxTime.Text != ""))
            {
                this.listView1.BeginUpdate();
                ListViewItem item = new ListViewItem {
                    Text = this.textBoxID.Text
                };
                this.listView1.Items.Add(item);
                ListViewItem.ListViewSubItem item2 = new ListViewItem.ListViewSubItem {
                    Text = this.textBoxTime.Text
                };
                item.SubItems.Add(item2);
                this.listView1.EndUpdate();
                this.buttonDelete.Enabled = true;
                this.textBoxID.Text = "";
                this.textBoxTime.Text = "";
            }
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            this.listView1.Items.Remove(this.listView1.SelectedItems[0]);
            if (this.listView1.Items.Count == 0)
            {
                this.buttonDelete.Enabled = false;
            }
        }

        private static void Console_CancelKeyPress(object sender, ConsoleCancelEventArgs e)
        {
            DoQuit();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        public static void DoQuit()
        {
            if (null != oSecureEndpoint)
            {
                oSecureEndpoint.Dispose();
            }
           // UninstallCertificate(); //删除 证书
            FiddlerApplication.Shutdown();
            RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Internet Settings", true);
            key.SetValue("ProxyEnable", 0);
            key.SetValue("ProxyServer", "");
            Thread.Sleep(500);
        }

        private static string Ellipsize(string s, int iLen)
        {
            if (s.Length <= iLen)
            {
                return s;
            }
            return (s.Substring(0, iLen - 3) + "...");
        }

        private void FormMain_Closing(object sender, EventArgs e)
        {
            UnregisterHotKey(base.Handle, 0x7b);
            DoQuit();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            RegisterHotKey(base.Handle, 0x7b, 2, Keys.F12);//定义热键
            this.UseFiddler();
            string str = "";
            str = this.makeKey();
            if (false)//(!this.isReged())
            {
                this.intFlag = 0;//关闭 封包处理
                this.Text = this.Text + "-未注册";
            }
            else
            {
                this.intFlag = 1;//开启 封包处理
                //this.Text = this.Text + "-已注册";
                this.txtKey.Enabled = false;
                this.button1.Enabled = false;
                //this.button1.Text = "已注册";
            }
        }

        public static string getCpu()
        {
            string str = null;
            ManagementClass class2 = new ManagementClass("win32_Processor");
            using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = class2.GetInstances().GetEnumerator())
            {
                if (enumerator.MoveNext())
                {
                    ManagementObject current = (ManagementObject) enumerator.Current;
                    str = current.Properties["Processorid"].Value.ToString();
                }
            }
            return str;
        }

        public static string GetDiskVolumeSerialNumber()
        {
            ManagementClass class2 = new ManagementClass("Win32_NetworkAdapterConfiguration");
            ManagementObject obj2 = new ManagementObject("win32_logicaldisk.deviceid=\"c:\"");
            obj2.Get();
            return obj2.GetPropertyValue("VolumeSerialNumber").ToString();
        }

        public static string getMNum()
        {
            return (getCpu() + GetDiskVolumeSerialNumber()).Substring(0, 0x18);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.textBoxID = new System.Windows.Forms.TextBox();
            this.buttonDelete = new System.Windows.Forms.Button();
            this.labelMachineID = new System.Windows.Forms.Label();
            this.textBoxMachineID = new System.Windows.Forms.TextBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxTime = new System.Windows.Forms.TextBox();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.numericUpDown5 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown6 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown7 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown8 = new System.Windows.Forms.NumericUpDown();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label9 = new System.Windows.Forms.Label();
            this.txtKey = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBoxlog = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxID
            // 
            this.textBoxID.Location = new System.Drawing.Point(17, 174);
            this.textBoxID.Name = "textBoxID";
            this.textBoxID.Size = new System.Drawing.Size(127, 21);
            this.textBoxID.TabIndex = 0;
            // 
            // buttonDelete
            // 
            this.buttonDelete.Enabled = false;
            this.buttonDelete.Location = new System.Drawing.Point(17, 240);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(55, 23);
            this.buttonDelete.TabIndex = 1;
            this.buttonDelete.Text = "删除";
            this.buttonDelete.UseVisualStyleBackColor = true;
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // labelMachineID
            // 
            this.labelMachineID.AutoSize = true;
            this.labelMachineID.Location = new System.Drawing.Point(17, 325);
            this.labelMachineID.Name = "labelMachineID";
            this.labelMachineID.Size = new System.Drawing.Size(41, 12);
            this.labelMachineID.TabIndex = 2;
            this.labelMachineID.Text = "机器码";
            // 
            // textBoxMachineID
            // 
            this.textBoxMachineID.Location = new System.Drawing.Point(76, 324);
            this.textBoxMachineID.Name = "textBoxMachineID";
            this.textBoxMachineID.Size = new System.Drawing.Size(266, 21);
            this.textBoxMachineID.TabIndex = 3;
            this.textBoxMachineID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(64, 16);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(42, 21);
            this.numericUpDown1.TabIndex = 4;
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(150, 16);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(45, 21);
            this.numericUpDown2.TabIndex = 5;
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Location = new System.Drawing.Point(248, 16);
            this.numericUpDown3.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(53, 21);
            this.numericUpDown3.TabIndex = 6;
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.Location = new System.Drawing.Point(354, 18);
            this.numericUpDown4.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(53, 21);
            this.numericUpDown4.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 8;
            this.label1.Text = "待付款";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(109, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 9;
            this.label2.Text = "待发货";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(201, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 10;
            this.label3.Text = "待收货";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(307, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 11;
            this.label4.Text = "待评价";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 47);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 12);
            this.label5.TabIndex = 12;
            this.label5.Text = "好评：最近一周";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 74);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 12);
            this.label6.TabIndex = 13;
            this.label6.Text = "好评：最近一月";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(17, 101);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(89, 12);
            this.label7.TabIndex = 14;
            this.label7.Text = "好评：最近六月";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(17, 128);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 12);
            this.label8.TabIndex = 15;
            this.label8.Text = "好评：六个月前";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(17, 159);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 17;
            this.label10.Text = "订单ID：";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(17, 198);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 12);
            this.label11.TabIndex = 18;
            this.label11.Text = "订单时间：";
            // 
            // textBoxTime
            // 
            this.textBoxTime.Location = new System.Drawing.Point(17, 213);
            this.textBoxTime.Name = "textBoxTime";
            this.textBoxTime.Size = new System.Drawing.Size(127, 21);
            this.textBoxTime.TabIndex = 19;
            // 
            // buttonAdd
            // 
            this.buttonAdd.Location = new System.Drawing.Point(89, 240);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(55, 23);
            this.buttonAdd.TabIndex = 20;
            this.buttonAdd.Text = "添加";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // numericUpDown5
            // 
            this.numericUpDown5.Location = new System.Drawing.Point(111, 45);
            this.numericUpDown5.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown5.Name = "numericUpDown5";
            this.numericUpDown5.Size = new System.Drawing.Size(58, 21);
            this.numericUpDown5.TabIndex = 21;
            // 
            // numericUpDown6
            // 
            this.numericUpDown6.Location = new System.Drawing.Point(111, 72);
            this.numericUpDown6.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown6.Name = "numericUpDown6";
            this.numericUpDown6.Size = new System.Drawing.Size(58, 21);
            this.numericUpDown6.TabIndex = 22;
            // 
            // numericUpDown7
            // 
            this.numericUpDown7.Location = new System.Drawing.Point(111, 99);
            this.numericUpDown7.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown7.Name = "numericUpDown7";
            this.numericUpDown7.Size = new System.Drawing.Size(58, 21);
            this.numericUpDown7.TabIndex = 23;
            // 
            // numericUpDown8
            // 
            this.numericUpDown8.Location = new System.Drawing.Point(111, 126);
            this.numericUpDown8.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown8.Name = "numericUpDown8";
            this.numericUpDown8.Size = new System.Drawing.Size(58, 21);
            this.numericUpDown8.TabIndex = 24;
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.listView1.Location = new System.Drawing.Point(202, 47);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(205, 250);
            this.listView1.TabIndex = 25;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "订单号";
            this.columnHeader1.Width = 126;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "日期";
            this.columnHeader2.Width = 74;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 354);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(47, 12);
            this.label9.TabIndex = 26;
            this.label9.Text = "注册码:";
            // 
            // txtKey
            // 
            this.txtKey.Location = new System.Drawing.Point(76, 351);
            this.txtKey.Name = "txtKey";
            this.txtKey.Size = new System.Drawing.Size(266, 21);
            this.txtKey.TabIndex = 27;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(348, 325);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 28;
            this.button1.Text = "注册软件";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBoxlog
            // 
            this.textBoxlog.Location = new System.Drawing.Point(427, 15);
            this.textBoxlog.MaxLength = 82767;
            this.textBoxlog.Multiline = true;
            this.textBoxlog.Name = "textBoxlog";
            this.textBoxlog.Size = new System.Drawing.Size(322, 282);
            this.textBoxlog.TabIndex = 29;
            // 
            // FormMain
            // 
            this.ClientSize = new System.Drawing.Size(761, 311);
            this.Controls.Add(this.textBoxlog);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtKey);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.numericUpDown8);
            this.Controls.Add(this.numericUpDown7);
            this.Controls.Add(this.numericUpDown6);
            this.Controls.Add(this.numericUpDown5);
            this.Controls.Add(this.buttonAdd);
            this.Controls.Add(this.textBoxTime);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numericUpDown4);
            this.Controls.Add(this.numericUpDown3);
            this.Controls.Add(this.numericUpDown2);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.textBoxMachineID);
            this.Controls.Add(this.labelMachineID);
            this.Controls.Add(this.buttonDelete);
            this.Controls.Add(this.textBoxID);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "后台服务";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormMain_Closing);
            this.Load += new System.EventHandler(this.FormMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        public bool isReged()//判断 当前目录下的 key.txt 是否注册
        {
            string str = "";
            try
            {
                if (File.Exists(Thread.GetDomain().BaseDirectory + "key.txt"))
                {
                    StreamReader reader = new StreamReader(Thread.GetDomain().BaseDirectory + "key.txt");
                    str = reader.ReadToEnd();
                    reader.Close();
                    return (str == this.makeKey());
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public string makeKey()//制造 key
        {
            this.machineID = getMNum();
            this.textBoxMachineID.Text = this.machineID;
            string s = this.machineID + "heiniusoft";
            byte[] bytes = Encoding.Default.GetBytes(s);
            MD5 md = new MD5CryptoServiceProvider();
            return BitConverter.ToString(md.ComputeHash(bytes)).Replace("-", "");
        }

        [DllImport("user32")]
        public static extern bool RegisterHotKey(IntPtr hWnd, int id, uint control, Keys vk);
        [DllImport("user32")]
        public static extern bool UnregisterHotKey(IntPtr hWnd, int id);
        public static bool InstallCertificate()
        {
            if (!CertMaker.rootCertExists())
            {
                if (!CertMaker.createRootCert())
                    return false;

                if (!CertMaker.trustRootCert())
                    return false;

                //app.Configuration.UrlCapture.Cert = FiddlerApplication.Prefs.GetStringPref("fiddler.certmaker.bc.cert", null);
               // app.Configuration.UrlCapture.Key = FiddlerApplication.Prefs.GetStringPref("fiddler.certmaker.bc.key", null);
            }

            return true;
        }

        public static bool UninstallCertificate()
        {
            if (CertMaker.rootCertExists())
            {
                if (!CertMaker.removeFiddlerGeneratedCerts(true))
                    return false;
            }
           // this.Configuration.UrlCapture.Cert = null;
           // this.Configuration.UrlCapture.Key = null;
            return true;
        }
        private void UseFiddler()
        {
            List<Session> oAllSessions = new List<Session>();
            FiddlerApplication.SetAppDisplayName("YoukuSpeed");
            FiddlerApplication.OnNotification += (sender, oNEA) => Console.WriteLine("** NotifyUser: " + oNEA.NotifyString);
            FiddlerApplication.Log.OnLogString += (sender, oLEA) => Console.WriteLine("** LogString: " + oLEA.LogString);
           // InstallCertificate();//证书处理

            FiddlerApplication.BeforeRequest += delegate (Session oS) {//事件,当接收到客户端请求
                oS.bBufferResponse = true;
                Monitor.Enter(oAllSessions);
                oAllSessions.Add(oS);
                Monitor.Exit(oAllSessions);
                oS["X-AutoAuth"] = "(default)";
                if ((oS.oRequest.pipeClient.LocalPort == iSecureEndpointPort) && (oS.hostname == sSecureEndpointHostname))
                {
                    oS.utilCreateResponseAndBypassServer();//创建响应对象 response
                    oS.oResponse.headers.SetStatus(200, "Ok");//设置响应头
                    oS.oResponse["Content-Type"] = "text/html; charset=UTF-8";
                    oS.oResponse["Cache-Control"] = "private, max-age=0";
                    oS.utilSetResponseBody("<html><body>Request for httpS://" + sSecureEndpointHostname + ":" + iSecureEndpointPort.ToString() + " received. Your request was:<br /><plaintext>" + oS.oRequest.headers.ToString());
                }
            };
            FiddlerApplication.BeforeResponse += delegate (Session oS) {//当 获取到 响应 数据 
                if (this.intFlag == 1)
                {
                    if (oS.uriContains("trade.taobao.com"))//web查看地址http://unit.buyer.trade.taobao.com/trade/itemlist/listBoughtItems.htm
                    {
                     
                        string sString = Regex.Replace(Regex.Replace(Regex.Replace(Regex.Replace(oS.GetResponseBodyAsString(), "待付款</span><em class=\"tm-h\">\\d*</em>", "待付款</span><em class=\"tm-h\">" + this.numericUpDown1.Value.ToString() + "</em>"), "待发货</span><em class=\"tm-h\">\\d*</em>", "待发货</span><em class=\"tm-h\">" + this.numericUpDown2.Value.ToString() + "</em>"), "待收货</span><em class=\"tm-h\">\\d*</em>", "待收货</span><em class=\"tm-h\">" + this.numericUpDown3.Value.ToString() + "</em>"), "待评价</span><em class=\"tm-h\">\\d*</em>", "待评价</span><em class=\"tm-h\">" + this.numericUpDown4.Value.ToString() + "</em>");
                        if (this.listView1.Items.Count > 0)
                        {
                            foreach (ListViewItem item in this.listView1.Items)
                            {
                                int index = sString.IndexOf("<tbody data-isarchive=\"false\" data-orderid=\"" + item.Text + "\"");
                                if (index >= 0)
                                {
                                    int num2 = sString.Substring(index).IndexOf("</tbody>");
                                    if (item.SubItems[1].Text == "0")
                                    {
                                        sString = sString.Substring(0, index) + sString.Substring((index + num2) + 8);
                                    }
                                    else
                                    {
                                        string str2 = Regex.Replace(sString.Substring(index, num2 + 8), @"\d*-\d*-\d*", item.SubItems[1].Text);
                                        sString = sString.Substring(0, index) + str2 + sString.Substring((index + num2) + 8);
                                    }
                                }
                            }
                        }
                        oS.utilSetResponseBody(sString);//设置响应主体
                    }

                    ///*========================自己添加的=======================
                    if (oS.uriContains("www.baidu.com/index"))
                     {
                         string sString = ">> " + oS.fullUrl + "\n" + oS.GetResponseBodyAsString();//oS.GetResponseBodyAsString();
                         this.textBoxlog.AppendText(sString = oS.GetResponseBodyAsString().Replace("百度一下", "一世如秋"));
                         oS.utilSetResponseBody(sString);
                     }
                    // ===============================================*/
                    
                    if (oS.uriContains("http://rate.taobao.com/"))
                    {
                        string responseBodyAsString = oS.GetResponseBodyAsString();
                        int startIndex = responseBodyAsString.IndexOf("<h4 class=\"buyer\">");
                        if (startIndex >= 0)
                        {
                            int length = responseBodyAsString.Substring(startIndex).IndexOf("</table>");
                            string str4 = responseBodyAsString.Substring(startIndex, length);
                            char[] separator = new char[] { '<', '>' };
                            string[] strArray = str4.Split(separator);
                            string str5 = "<";
                            int num5 = 1;
                            while (num5 < strArray.Length)
                            {
                                int num6 = num5;
                                if (num6 <= 0xa6)
                                {
                                    if (num6 <= 0x76)
                                    {
                                        if (num6 <= 0x60)
                                        {
                                            if (num6 != 0x58)
                                            {
                                                if (num6 != 0x60)
                                                {
                                                    goto Label_0739;
                                                }
                                                str5 = str5 + this.numericUpDown6.Value;
                                            }
                                            else
                                            {
                                                str5 = str5 + this.numericUpDown5.Value;
                                            }
                                        }
                                        else if (num6 == 0x68)
                                        {
                                            str5 = str5 + this.numericUpDown7.Value;
                                        }
                                        else if (num6 != 0x70)
                                        {
                                            if (num6 != 0x76)
                                            {
                                                goto Label_0739;
                                            }
                                            str5 = str5 + (((this.numericUpDown5.Value + this.numericUpDown6.Value) + this.numericUpDown7.Value) + this.numericUpDown8.Value);
                                        }
                                        else
                                        {
                                            str5 = str5 + this.numericUpDown8.Value;
                                        }
                                    }
                                    else if (num6 <= 0x90)
                                    {
                                        if (num6 != 0x88)
                                        {
                                            if (num6 != 0x90)
                                            {
                                                goto Label_0739;
                                            }
                                            str5 = str5 + 0;
                                        }
                                        else
                                        {
                                            str5 = str5 + 0;
                                        }
                                    }
                                    else if (num6 == 0x98)
                                    {
                                        str5 = str5 + 0;
                                    }
                                    else if (num6 != 160)
                                    {
                                        if (num6 != 0xa6)
                                        {
                                            goto Label_0739;
                                        }
                                        str5 = str5 + 0;
                                    }
                                    else
                                    {
                                        str5 = str5 + 0;
                                    }
                                }
                                else if (num6 <= 0xd6)
                                {
                                    if (num6 <= 0xc0)
                                    {
                                        if (num6 != 0xb8)
                                        {
                                            if (num6 != 0xc0)
                                            {
                                                goto Label_0739;
                                            }
                                            str5 = str5 + 0;
                                        }
                                        else
                                        {
                                            str5 = str5 + 0;
                                        }
                                    }
                                    else if (num6 == 200)
                                    {
                                        str5 = str5 + 0;
                                    }
                                    else if (num6 != 0xd0)
                                    {
                                        if (num6 != 0xd6)
                                        {
                                            goto Label_0739;
                                        }
                                        str5 = str5 + 0;
                                    }
                                    else
                                    {
                                        str5 = str5 + 0;
                                    }
                                }
                                else if (num6 <= 0xec)
                                {
                                    if (num6 != 0xe4)
                                    {
                                        if (num6 != 0xec)
                                        {
                                            goto Label_0739;
                                        }
                                        str5 = str5 + this.numericUpDown6.Value;
                                    }
                                    else
                                    {
                                        str5 = str5 + this.numericUpDown5.Value;
                                    }
                                }
                                else if (num6 != 0xf4)
                                {
                                    if (num6 != 0xfc)
                                    {
                                        if (num6 != 0x102)
                                        {
                                            goto Label_0739;
                                        }
                                        str5 = str5 + (((this.numericUpDown5.Value + this.numericUpDown6.Value) + this.numericUpDown7.Value) + this.numericUpDown8.Value);
                                    }
                                    else
                                    {
                                        str5 = str5 + this.numericUpDown8.Value;
                                    }
                                }
                                else
                                {
                                    str5 = str5 + this.numericUpDown7.Value;
                                }
                            Label_06FF:
                                if ((num5 % 2) == 1)
                                {
                                    str5 = str5 + ">";
                                }
                                else
                                {
                                    str5 = str5 + "<";
                                }
                                num5++;
                                continue;
                            Label_0739:
                                str5 = str5 + strArray[num5];
                                goto Label_06FF;
                            }
                            responseBodyAsString = responseBodyAsString.Substring(0, startIndex) + str5 + "/table>" + responseBodyAsString.Substring((startIndex + length) + 8);
                        }
                        oS.utilSetResponseBody(responseBodyAsString);
                    }
                }
            };
            FiddlerApplication.AfterSessionComplete += delegate (Session oS) {//事件:当会话完成时
            };
            Console.CancelKeyPress += new ConsoleCancelEventHandler(FormMain.Console_CancelKeyPress);
            string str = "NoSAZ";
            Console.WriteLine(string.Format("Starting {0} ({1})...", FiddlerApplication.GetVersionString(), str));
            //CONFIG.IgnoreServerCertErrors = false;//开启这个 https 无法修改
            FiddlerApplication.Prefs.SetBoolPref("fiddler.network.streaming.abortifclientaborts", true);
            FiddlerCoreStartupFlags oFlags = FiddlerCoreStartupFlags.Default;
            //oFlags &= ~FiddlerCoreStartupFlags.DecryptSSL;//开启这个 会关闭 https获取
            int iListenPort = 8877;
            FiddlerApplication.Startup(iListenPort, oFlags);
            FiddlerApplication.Log.LogFormat("Created endpoint listening on port {0}", new object[] { iListenPort });
            FiddlerApplication.Log.LogFormat("Starting with settings: [{0}]", new object[] { oFlags });
            FiddlerApplication.Log.LogFormat("Gateway: {0}", new object[] { CONFIG.UpstreamGateway.ToString() });
            oSecureEndpoint = FiddlerApplication.CreateProxyEndpoint(iSecureEndpointPort, true, sSecureEndpointHostname);
            if (null != oSecureEndpoint)
            {
                FiddlerApplication.Log.LogFormat("Created secure endpoint listening on port {0}, using a HTTPS certificate for '{1}'", new object[] { iSecureEndpointPort, sSecureEndpointHostname });
            }
        }

        protected override void WndProc(ref Message m)
        {
            if ((m.Msg == 0x312) && (m.WParam.ToString() == "123"))
            {
                if (base.Visible)
                {
                    base.Hide();
                }
                else
                {
                    base.Visible = true;
                }
            }
            base.WndProc(ref m);
        }//窗口 显示隐藏

        public static void WriteCommandResponse(string s)
        {
            ConsoleColor foregroundColor = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(s);
            Console.ForegroundColor = foregroundColor;
        }

        private static void WriteSessionList(List<Session> oAllSessions)
        {
            ConsoleColor foregroundColor = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Session list contains...");
            try
            {
                Monitor.Enter(oAllSessions);
                foreach (Session session in oAllSessions)
                {
                    Console.Write(string.Format("{0} {1} {2}\n{3} {4}\n\n", new object[] { session.id, session.oRequest.headers.HTTPMethod, Ellipsize(session.fullUrl, 60), session.responseCode, session.oResponse.MIMEType }));
                }
            }
            finally
            {
                Monitor.Exit(oAllSessions);
            }
            Console.WriteLine();
            Console.ForegroundColor = foregroundColor;
        }
    }
}
