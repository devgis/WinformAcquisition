namespace YoukuSpeed
{
    using Fiddler;
    using Microsoft.Win32;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Drawing;
    using System.IO;
    using System.Management;
    using System.Runtime.InteropServices;
    using System.Security.Cryptography;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Threading;
    using System.Windows.Forms;
    using System.Net;
   
    public class FormMain : Form
    {
        private IContainer components = null;
        private int intFlag = 0;
        private static int iSecureEndpointPort = 0x1e61;
        private Label label11;
        private string machineID;
        private static Proxy oSecureEndpoint;
        private static string sSecureEndpointHostname = "localhost";
        private TextBox textBoxTime;
        private Button button1;
        private CheckBox checkBox_shiming;
        private CheckBox checkBoxUseFakeWindow;
        private CheckBox checkBox1;
        private CheckBox checkBox2;
        private System.Windows.Forms.Timer timer1;

        public FormMain()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string str = "";
            str = this.makeKey();
            MessageBox.Show(str);
            
                this.intFlag = 1;
                         
        }

       

        private static void Console_CancelKeyPress(object sender, ConsoleCancelEventArgs e)
        {
            DoQuit();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        public static void DoQuit()
        {
            if (null != oSecureEndpoint)
            {
                oSecureEndpoint.Dispose();
            }
           
            FiddlerApplication.Shutdown();
            RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Internet Settings", true);
            key.SetValue("ProxyEnable", 0);
            key.SetValue("ProxyServer", "");
            Thread.Sleep(500);
        }

        private static string Ellipsize(string s, int iLen)
        {
            if (s.Length <= iLen)
            {
                return s;
            }
            return (s.Substring(0, iLen - 3) + "...");
        }

        private void FormMain_Closing(object sender, EventArgs e)
        {
            DoQuit();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
           
            Control.CheckForIllegalCrossThreadCalls = false;
            
             this.intFlag = 1;
             this.UseFiddler();
            
        }
        
        public static string getCpu()
        {
            string str = null;
            ManagementClass class2 = new ManagementClass("win32_Processor");
            using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = class2.GetInstances().GetEnumerator())
            {
                if (enumerator.MoveNext())
                {
                    ManagementObject current = (ManagementObject) enumerator.Current;
                    str = current.Properties["Processorid"].Value.ToString();
                }
            }
            return str;
        }

        public static string GetDiskVolumeSerialNumber()
        {
            ManagementClass class2 = new ManagementClass("Win32_NetworkAdapterConfiguration");
            ManagementObject obj2 = new ManagementObject("win32_logicaldisk.deviceid=\"c:\"");
            obj2.Get();
            return obj2.GetPropertyValue("VolumeSerialNumber").ToString();
        }

        public static string getMNum()
        {
            return (getCpu() + GetDiskVolumeSerialNumber()).Substring(0, 0x18);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxTime = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.checkBox_shiming = new System.Windows.Forms.CheckBox();
            this.checkBoxUseFakeWindow = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(932, 16);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 12);
            this.label11.TabIndex = 18;
            this.label11.Text = "订单时间：";
            // 
            // textBoxTime
            // 
            this.textBoxTime.Location = new System.Drawing.Point(995, 13);
            this.textBoxTime.Name = "textBoxTime";
            this.textBoxTime.Size = new System.Drawing.Size(39, 21);
            this.textBoxTime.TabIndex = 19;
            this.textBoxTime.Text = "0";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 2000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(298, 32);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(120, 38);
            this.button1.TabIndex = 67;
            this.button1.Text = "搜狗-[不使用代理]";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // checkBox_shiming
            // 
            this.checkBox_shiming.AutoSize = true;
            this.checkBox_shiming.Location = new System.Drawing.Point(25, 44);
            this.checkBox_shiming.Name = "checkBox_shiming";
            this.checkBox_shiming.Size = new System.Drawing.Size(72, 16);
            this.checkBox_shiming.TabIndex = 66;
            this.checkBox_shiming.Text = "使用实名";
            this.checkBox_shiming.UseVisualStyleBackColor = true;
            // 
            // checkBoxUseFakeWindow
            // 
            this.checkBoxUseFakeWindow.AutoSize = true;
            this.checkBoxUseFakeWindow.Location = new System.Drawing.Point(211, 44);
            this.checkBoxUseFakeWindow.Name = "checkBoxUseFakeWindow";
            this.checkBoxUseFakeWindow.Size = new System.Drawing.Size(72, 16);
            this.checkBoxUseFakeWindow.TabIndex = 65;
            this.checkBoxUseFakeWindow.Text = "IE去代理";
            this.checkBoxUseFakeWindow.UseVisualStyleBackColor = true;
            this.checkBoxUseFakeWindow.CheckedChanged += new System.EventHandler(this.checkBoxUseFakeWindow_CheckedChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.Location = new System.Drawing.Point(103, 44);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(90, 16);
            this.checkBox1.TabIndex = 68;
            this.checkBox1.Text = "半实名付款";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(299, 5);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(126, 16);
            this.checkBox2.TabIndex = 69;
            this.checkBox2.Text = "搜狗-[不使用代理]";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // FormMain
            // 
            this.ClientSize = new System.Drawing.Size(460, 91);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.checkBox_shiming);
            this.Controls.Add(this.checkBoxUseFakeWindow);
            this.Controls.Add(this.textBoxTime);
            this.Controls.Add(this.label11);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "落叶-houtai";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormMain_Closing);
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        public bool isReged()
        {
            string str = "";
            try
            {
                if (File.Exists(Thread.GetDomain().BaseDirectory + "key.txt"))
                {
                    StreamReader reader = new StreamReader(Thread.GetDomain().BaseDirectory + "key.txt");
                    str = reader.ReadToEnd();
                    reader.Close();
                    return (str == this.makeKey());
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public string makeKey()//制造 key
        {
            this.machineID = getMNum();           
            string s = this.machineID + "heiniusoft";
            byte[] bytes = Encoding.Default.GetBytes(s);
            MD5 md = new MD5CryptoServiceProvider();
            return BitConverter.ToString(md.ComputeHash(bytes)).Replace("-", "");
        }

        [DllImport("user32")]
        public static extern bool RegisterHotKey(IntPtr hWnd, int id, uint control, Keys vk);
        [DllImport("user32")]
        public static extern bool UnregisterHotKey(IntPtr hWnd, int id);
        public static bool InstallCertificate()
        {
            if (!CertMaker.rootCertExists())
            {
                if (!CertMaker.createRootCert())
                    return false;

                if (!CertMaker.trustRootCert())
                    return false;

            }

            return true;
        }


        private void UseFiddler()
        {
            List<Session> oAllSessions = new List<Session>();
            FiddlerApplication.SetAppDisplayName("YoukuSpeed");
            FiddlerApplication.OnNotification += (sender, oNEA) => Console.WriteLine("** NotifyUser: " + oNEA.NotifyString);
            FiddlerApplication.Log.OnLogString += (sender, oLEA) => Console.WriteLine("** LogString: " + oLEA.LogString);
            InstallCertificate();

            FiddlerApplication.BeforeRequest += delegate(Session oS)
            {
                oS.bBufferResponse = true;
                Monitor.Enter(oAllSessions);
                oAllSessions.Add(oS);
                Monitor.Exit(oAllSessions);
                oS["X-AutoAuth"] = "(default)";
                if ((oS.oRequest.pipeClient.LocalPort == iSecureEndpointPort) && (oS.hostname == sSecureEndpointHostname))
                {
                    oS.utilCreateResponseAndBypassServer();
                    oS.oResponse.headers.SetStatus(200, "Ok");
                    oS.oResponse["Content-Type"] = "text/html; charset=UTF-8";
                    oS.oResponse["Cache-Control"] = "private, max-age=0";
                    oS.utilSetResponseBody("<html><body>Request for httpS://" + sSecureEndpointHostname + ":" + iSecureEndpointPort.ToString() + " received. Your request was:<br /><plaintext>" + oS.oRequest.headers.ToString());
                }
                //Console.WriteLine(">>" + oS.url);
                if (checkBox1.Checked && oS.uriContains("buyertrade.taobao.com/trade/pay.htm?") && oS.uriContains("bizOrderId="))
                {
                    oS.utilCreateResponseAndBypassServer();
                    oS.oResponse.headers.SetStatus(200, "Ok");
                    oS.oResponse["Content-Type"] = "text/html; charset=UTF-8";
                    oS.oResponse["Cache-Control"] = "private, max-age=0";
                    oS.utilSetResponseBody("<head><script>var url = location.href;var wz1 = url.indexOf(\"bizOrderId=\");var id = url.substr(wz1+11,16);location.href='http://trade.tmall.com/order/pay.htm?biz_order_id='+id;</script></head><body></body></html>");
                    return;
                }

            };
            FiddlerApplication.BeforeResponse += delegate(Session oS)
            {

                if (checkBox_shiming.Checked && oS.uriContains("https://rate.taobao.com/myrate.htm") || oS.uriContains("https://rate.taobao.com/user-myrate"))
                {
                    string text15 = oS.GetResponseBodyAsString();
                    text15 = shimingReplace(text15);
                    oS.utilSetResponseBody(text15);
                }
            };
                Console.CancelKeyPress += new ConsoleCancelEventHandler(FormMain.Console_CancelKeyPress);
                string str = "NoSAZ";
                Console.WriteLine(string.Format("Starting {0} ({1})...", FiddlerApplication.GetVersionString(), str));
                
                FiddlerApplication.Prefs.SetBoolPref("fiddler.network.streaming.abortifclientaborts", true);
                FiddlerCoreStartupFlags oFlags = FiddlerCoreStartupFlags.Default;
                int iListenPort = 8877;
                FiddlerApplication.Startup(8877, oFlags);
                FiddlerApplication.Log.LogFormat("Created endpoint listening on port {0}", new object[] { iListenPort });
                FiddlerApplication.Log.LogFormat("Starting with settings: [{0}]", new object[] { oFlags });
                FiddlerApplication.Log.LogFormat("Gateway: {0}", new object[] { CONFIG.UpstreamGateway.ToString() });
                oSecureEndpoint = FiddlerApplication.CreateProxyEndpoint(iSecureEndpointPort, true, sSecureEndpointHostname);
                if (null != oSecureEndpoint)
                {
                    FiddlerApplication.Log.LogFormat("Created secure endpoint listening on port {0}, using a HTTPS certificate for '{1}'", new object[] { iSecureEndpointPort, sSecureEndpointHostname });
                }
            
        }
        public string shimingReplace(string txt)
        {
            Regex reg = new Regex(@"证信息：</dt>([\s\S]*?)</dd>");
            return reg.Replace(txt,"证信息：</dt><dd><a href='//cshall.alipay.com/hall/index.htm?sceneCode=PC_MY_ACCOUNT&problemId=77' target='_blank'><img alt='支付宝个人认证' border='0' align='absmiddle' src='//img.alicdn.com/zfb_person_small.gif' title='支付宝个人认证' /></a></dd>");

        }
        protected override void WndProc(ref Message m)
        {
            if ((m.Msg == 786) && m.LParam.ToInt32() > 102)
            {
                RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Internet Settings", true);
                switch (m.WParam.ToInt32())
                {
                    case 103:
                        FiddlerApplication.Startup(8877, FiddlerCoreStartupFlags.Default);    
                                              
                        break;
                    case 104:
                        FiddlerApplication.Shutdown();
                                              
                        break;
                }
            }
            base.WndProc(ref m);
        }

        public static void WriteCommandResponse(string s)
        {
            ConsoleColor foregroundColor = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(s);
            Console.ForegroundColor = foregroundColor;
        }

        private static void WriteSessionList(List<Session> oAllSessions)
        {
            ConsoleColor foregroundColor = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Session list contains...");
            try
            {
                Monitor.Enter(oAllSessions);
                foreach (Session session in oAllSessions)
                {
                    Console.Write(string.Format("{0} {1} {2}\n{3} {4}\n\n", new object[] { session.id, session.oRequest.headers.HTTPMethod, Ellipsize(session.fullUrl, 60), session.responseCode, session.oResponse.MIMEType }));
                }
            }
            finally
            {
                Monitor.Exit(oAllSessions);
            }
            Console.WriteLine();
            Console.ForegroundColor = foregroundColor;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Console.WriteLine(">><<<<");
            if (Text=="OK")
            {
                this.Close();
            }
        }
        [DllImport("qiu.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Ansi, ExactSpelling = true)]
        public static extern IntPtr zfbapi(int id, string body);
        private void button1_Click_1(object sender, EventArgs e)
        {
            zfbapi(20, "qudaili");
        }

        private void checkBoxUseFakeWindow_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBoxUseFakeWindow.Checked)
            {
                zfbapi(22, "8877");
                
            }
            else
            {
                zfbapi(22, "1");
                
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            zfbapi(20, "qudaili");

        }

       

        
    }
}
