﻿using log4net.Config;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: ComVisible(false)]
[assembly: XmlConfigurator(ConfigFile = "./JDSTHelper.exe.config", ConfigFileExtension = "config", Watch = true)]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCopyright("Copyright ©  2015")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("explorer")]
[assembly: AssemblyTitle("explorer")]
[assembly: Guid("b803da07-97ee-47ec-a8c0-f6e3a141ec39")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyVersion("1.0.0.0")]
