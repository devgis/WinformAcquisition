﻿
// Type: IEProxyManagment.PerConnOption
// Assembly: TobaoHelper, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 225AFE11-BEB6-419B-87A8-C7FB1B58441F
// Assembly location: C:\Users\Administrator\Desktop\程序\AliTrademanager.exe

namespace IEProxyManagment
{
  public enum PerConnOption
  {
    INTERNET_PER_CONN_FLAGS = 1,
    INTERNET_PER_CONN_PROXY_SERVER = 2,
    INTERNET_PER_CONN_PROXY_BYPASS = 3,
    INTERNET_PER_CONN_AUTOCONFIG_URL = 4,
  }
}
