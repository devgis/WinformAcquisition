﻿
// Type: TobaoHelper.Alipay.AP_TradeRecord
// Assembly: TobaoHelper, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 225AFE11-BEB6-419B-87A8-C7FB1B58441F
// Assembly location: C:\Users\Administrator\Desktop\程序\AliTrademanager.exe

namespace TobaoHelper.Alipay
{
  public class AP_TradeRecord
  {
    public long id { get; set; }

    public string tradeNo { get; set; }
  }
}
