﻿
// Type: TobaoHelper.APJS_TradeRecord
// Assembly: TobaoHelper, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 225AFE11-BEB6-419B-87A8-C7FB1B58441F
// Assembly location: C:\Users\Administrator\Desktop\程序\AliTrademanager.exe

namespace TobaoHelper
{
  public class APJS_TradeRecord
  {
    public string tradeNo { get; set; }

    public string tradeType { get; set; }

    public long id { get; set; }
  }
}
