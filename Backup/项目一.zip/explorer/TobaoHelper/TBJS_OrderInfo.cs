﻿
// Type: TobaoHelper.TBJS_OrderInfo
// Assembly: TobaoHelper, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 225AFE11-BEB6-419B-87A8-C7FB1B58441F
// Assembly location: C:\Users\Administrator\Desktop\程序\AliTrademanager.exe

namespace TobaoHelper
{
  public class TBJS_OrderInfo
  {
    public bool alic2c { get; set; }

    public bool archive { get; set; }

    public bool b2C { get; set; }

    public string createDay { get; set; }

    public string createTime { get; set; }

    public string id { get; set; }

    public string[] labels { get; set; }

    public bool peer { get; set; }

    public bool phaseTrade { get; set; }

    public bool showConsignTime { get; set; }

    public bool tripProduct { get; set; }
  }
}
