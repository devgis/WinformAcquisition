﻿
// Type: TobaoHelper.TBJS_Tab
// Assembly: TobaoHelper, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 225AFE11-BEB6-419B-87A8-C7FB1B58441F
// Assembly location: C:\Users\Administrator\Desktop\程序\AliTrademanager.exe

namespace TobaoHelper
{
  public class TBJS_Tab
  {
    public string code { get; set; }

    public string herf { get; set; }

    public bool selected { get; set; }

    public string text { get; set; }

    public string type { get; set; }

    public int? count { get; set; }
  }
}
