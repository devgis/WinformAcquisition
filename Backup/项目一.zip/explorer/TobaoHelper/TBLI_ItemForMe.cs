﻿
// Type: TobaoHelper.TBLI_ItemForMe
// Assembly: TobaoHelper, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 225AFE11-BEB6-419B-87A8-C7FB1B58441F
// Assembly location: C:\Users\Administrator\Desktop\程序\AliTrademanager.exe

namespace TobaoHelper
{
  public class TBLI_ItemForMe
  {
    public string itemName;
    public int itemNum;
    public string itemOrderStatus;
    public string mailNo;
    public string picUrl;
    public long sellerId;
    public bool shangChao;
    public string statusDesc;
    public string statusTime;
    public string tpName;
    public TBLI_TraceDetail[] traceDetailList;
    public long tradeId;
    public bool useLogistics;
    public string wuliuDetailUrl;
  }
}
