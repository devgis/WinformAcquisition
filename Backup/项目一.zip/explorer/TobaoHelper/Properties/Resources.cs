﻿
// Type: TobaoHelper.Properties.Resources
// Assembly: TobaoHelper, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 225AFE11-BEB6-419B-87A8-C7FB1B58441F
// Assembly location: C:\Users\Administrator\Desktop\程序\AliTrademanager.exe

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace TobaoHelper.Properties
{
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
  [DebuggerNonUserCode]
  [CompilerGenerated]
  internal class Resources
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (object.ReferenceEquals((object) Resources.resourceMan, (object) null))
          Resources.resourceMan = new ResourceManager("TobaoHelper.Properties.Resources", typeof (Resources).Assembly);
        return Resources.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get
      {
        return Resources.resourceCulture;
      }
      set
      {
        Resources.resourceCulture = value;
      }
    }

    internal static Bitmap _0
    {
      get
      {
        return (Bitmap) Resources.ResourceManager.GetObject("_0", Resources.resourceCulture);
      }
    }

    internal static Bitmap _1
    {
      get
      {
        return (Bitmap) Resources.ResourceManager.GetObject("_1", Resources.resourceCulture);
      }
    }

    internal static Bitmap _2
    {
      get
      {
        return (Bitmap) Resources.ResourceManager.GetObject("_2", Resources.resourceCulture);
      }
    }

    internal static Bitmap _3
    {
      get
      {
        return (Bitmap) Resources.ResourceManager.GetObject("_3", Resources.resourceCulture);
      }
    }

    internal static Bitmap _4
    {
      get
      {
        return (Bitmap) Resources.ResourceManager.GetObject("_4", Resources.resourceCulture);
      }
    }

    internal static Bitmap _5
    {
      get
      {
        return (Bitmap) Resources.ResourceManager.GetObject("_5", Resources.resourceCulture);
      }
    }

    internal static Bitmap android
    {
      get
      {
        return (Bitmap) Resources.ResourceManager.GetObject("android", Resources.resourceCulture);
      }
    }

    internal static Icon app
    {
      get
      {
        return (Icon) Resources.ResourceManager.GetObject("app", Resources.resourceCulture);
      }
    }

    internal Resources()
    {
    }
  }
}
