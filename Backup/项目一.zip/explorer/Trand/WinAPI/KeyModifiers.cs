﻿
// Type: Trand.WinApi.KeyModifiers
// Assembly: TobaoHelper, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 225AFE11-BEB6-419B-87A8-C7FB1B58441F
// Assembly location: C:\Users\Administrator\Desktop\程序\AliTrademanager.exe

using System;

namespace Trand.WinApi
{
  [Flags]
  public enum KeyModifiers
  {
    None = 0,
    Alt = 1,
    Ctrl = 2,
    Shift = 4,
    WindowsKey = 8,
  }
}
