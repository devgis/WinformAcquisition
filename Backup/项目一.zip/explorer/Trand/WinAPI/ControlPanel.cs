﻿
// Type: Trand.WinAPI.ControlPanel
// Assembly: TobaoHelper, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 225AFE11-BEB6-419B-87A8-C7FB1B58441F
// Assembly location: C:\Users\Administrator\Desktop\程序\AliTrademanager.exe

namespace Trand.WinAPI
{
  public enum ControlPanel
  {
    辅助功能选项,
    添加或删除程序,
    显示属性,
    Windows防火墙,
    添加硬件向导,
    Internet属性,
    区域和语言选项,
    游戏控制器,
    鼠标属性,
    声音和音频设备属性,
    网络连接,
    网络安装向导,
    用户账户,
    ODBC数据元管理器,
    电源选项,
    系统属性,
    位置信息,
    日期和时间属性,
    Windows安全中心,
    自动更新,
  }
}
