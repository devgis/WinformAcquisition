﻿
// Type: Trand.WinAPI.HARDWAREINPUT
// Assembly: TobaoHelper, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 225AFE11-BEB6-419B-87A8-C7FB1B58441F
// Assembly location: C:\Users\Administrator\Desktop\程序\AliTrademanager.exe

namespace Trand.WinAPI
{
  public struct HARDWAREINPUT
  {
    public int uMsg;
    public short wParamL;
    public short wParamH;
  }
}
