﻿
// Type: Trand.WinAPI.TernaryRasterOperations
// Assembly: TobaoHelper, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 225AFE11-BEB6-419B-87A8-C7FB1B58441F
// Assembly location: C:\Users\Administrator\Desktop\程序\AliTrademanager.exe

namespace Trand.WinAPI
{
  public enum TernaryRasterOperations : uint
  {
    BLACKNESS = 66U,
    NOTSRCERASE = 1114278U,
    NOTSRCCOPY = 3342344U,
    SRCERASE = 4457256U,
    DSTINVERT = 5570569U,
    PATINVERT = 5898313U,
    SRCINVERT = 6684742U,
    SRCAND = 8913094U,
    MERGEPAINT = 12255782U,
    MERGECOPY = 12583114U,
    SRCCOPY = 13369376U,
    SRCPAINT = 15597702U,
    PATCOPY = 15728673U,
    PATPAINT = 16452105U,
    WHITENESS = 16711778U,
    CAPTUREBLT = 1073741824U,
  }
}
